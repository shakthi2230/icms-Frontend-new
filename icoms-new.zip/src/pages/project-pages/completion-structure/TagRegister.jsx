import React from 'react'

function TagRegister() {
  return (
    <div>TagRegister</div>
  )
}

export default TagRegister