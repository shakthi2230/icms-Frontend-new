import React from 'react'

function ImportsReports() {
  return (
    <div>ImportsReports</div>
  )
}

export default ImportsReports