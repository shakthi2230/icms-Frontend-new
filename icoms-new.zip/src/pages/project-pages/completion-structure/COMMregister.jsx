import React from 'react'

function COMMregister() {
  return (
    <div>COMMregister</div>
  )
}

export default COMMregister