import React from 'react'

function CompletionStructure() {
  return (
    <div>CompletionStructure</div>
  )
}

export default CompletionStructure