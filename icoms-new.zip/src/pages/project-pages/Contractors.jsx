import React from 'react'

function Contractors() {
  return (
    <div>Contractors</div>
  )
}

export default Contractors