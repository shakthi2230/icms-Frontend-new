import React from 'react'

function SystemStructure() {
  return (
    <div>SystemStructure</div>
  )
}

export default SystemStructure