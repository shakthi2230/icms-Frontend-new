// AdminRoutes.js
import { Routes, Route } from "react-router-dom";
import Layout from "../components/Layout";

// Pages
import AdminLogin from "../pages/logins/AdminLogin";
import AdminDashboard from "../pages/admin-pages/AdminDashboard";

// Icons
import { LogOut } from "lucide-react";

export default function AdminRoutes() {
  const adminConfig = {
    logo: { name: "IComS", href: "/", color: "blue" },
    menuItems: [],
    footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
  };

  const adminDashboardConfig = {
    logo: { name: "IComS", href: "/admin-dashboard", color: "green" },
    menuItems: [],
    footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
  };

  return (
    <Routes>
      <Route path="/admin-login" element={<Layout title="Admin Login" config={adminConfig} />}>
        <Route index element={<AdminLogin />} />
      </Route>
      <Route path="/admin-dashboard" element={<Layout title="Admin Dashboard" config={adminDashboardConfig} />}>
        <Route index element={<AdminDashboard />} />
      </Route>
    </Routes>
  );
}
