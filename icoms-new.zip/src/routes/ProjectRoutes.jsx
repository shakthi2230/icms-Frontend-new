// ProjectRoutes.js
import { Routes, Route } from "react-router-dom";
import Layout from "../components/Layout";

// Pages
import ProjectLogin from "../pages/logins/ProjectLogin";
import ProjectDashboard from "../pages/project-pages/ProjectDashboard";
import Contractors from "../pages/project-pages/Contractors";
import SystemStructure from "../pages/project-pages/SystemStructure";
import CheckListandCertificates from "../pages/project-pages/CheckListandCertificates";
import CompletionStructure from "../pages/project-pages/CompletionStructure";
import CheckList from "../pages/project-pages/completion-structure/CheckLists";
import ImportsReports from "../pages/project-pages/completion-structure/ImportsReports";
import PunchItems from "../pages/project-pages/completion-structure/PunchItems";
import TagRegister from "../pages/project-pages/completion-structure/TagRegister";
import COMMregister from "../pages/project-pages/completion-structure/COMMregister";

// Icons
import { LogOut, LogIn } from "lucide-react";

export default function ProjectRoutes() {
  const projectConfig = {
    logo: { name: "IComS", href: "/", color: "green" },
    menuItems: [],
    footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
  };

  const projectDashboardConfig = {
    logo: { name: "IComS", href: "/project-dashboard", color: "green" },
    menuItems: [
      { label: "Check Lists & Certificates", icon: LogIn, href: "checklist-certificates" },
      { label: "Contractors", icon: LogIn, href: "contractors" },
      { label: "System Structure", icon: LogIn, href: "SystemStructure" },
      { label: "Completion Structure", icon: LogIn, href: "completionStructure" },
    ],
    footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
  };

  const completionStructureConfig = {
    logo: { name: "IComS", href: "/project-dashboard", color: "green" },
    menuItems: [
      { label: "Punch Items", icon: LogIn, href: "punchitems" },
      { label: "Check Lists", icon: LogIn, href: "checklist" },
      { label: "Tag Register", icon: LogIn, href: "tag-rgister" },
      { label: "COMM Systems", icon: LogIn, href: "comm-register" },
      { label: "Imports & Reports", icon: LogIn, href: "imports-reports" },
    ],
    footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
  };

  return (
    <Routes>
      <Route path="/project-login" element={<Layout title="Project Login" config={projectConfig} />}>
        <Route index element={<ProjectLogin />} />
      </Route>
      <Route path="/project-dashboard" element={<Layout title="Project Dashboard" config={projectDashboardConfig} />}>
        <Route index element={<ProjectDashboard />} />
      </Route>
      <Route path="/checklist-certificates" element={<Layout title="CheckList & Certificates" config={projectDashboardConfig} />}>
        <Route index element={<CheckListandCertificates />} />
      </Route>
      <Route path="/contractors" element={<Layout title="Contractors" config={projectDashboardConfig} />}>
        <Route index element={<Contractors />} />
      </Route>
      <Route path="/SystemStructure" element={<Layout title="System Structure" config={projectDashboardConfig} />}>
        <Route index element={<SystemStructure />} />
      </Route>
      <Route path="/completionStructure" element={<Layout title="Completion Structure" config={completionStructureConfig} />}>
        <Route index element={<CompletionStructure />} />
      </Route>
      <Route path="/checklist" element={<Layout title="CheckList" config={completionStructureConfig} />}>
        <Route index element={<CheckList />} />
      </Route>
      <Route path="/imports-reports" element={<Layout title="Imports & Reports" config={completionStructureConfig} />}>
        <Route index element={<ImportsReports />} />
      </Route>
      <Route path="/punchitems" element={<Layout title="Punch Items" config={completionStructureConfig} />}>
        <Route index element={<PunchItems />} />
      </Route>
      <Route path="/tag-rgister" element={<Layout title="Tag Register" config={completionStructureConfig} />}>
        <Route index element={<TagRegister />} />
      </Route>
      <Route path="/comm-register" element={<Layout title="COMM Systems" config={completionStructureConfig} />}>
        <Route index element={<COMMregister />} />
      </Route>
    </Routes>
  );
}
