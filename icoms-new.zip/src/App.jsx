import { BrowserRouter, Routes, Route, Outlet } from "react-router-dom";
import Layout from "./components/Layout";

// Pages
import Home from "./pages/Home";
import AdminLogin from "./pages/logins/AdminLogin";
import ProjectLogin from "./pages/logins/ProjectLogin";
import AdminDashboard from "./pages/admin-pages/AdminDashboard";
import ProjectDashboard from "./pages/project-pages/ProjectDashboard";
import Contractors from "./pages/project-pages/Contractors";
import SystemStructure from "./pages/project-pages/SystemStructure";
import CheckListandCertificates from "./pages/project-pages/CheckListandCertificates";
import CompletionStructure from "./pages/project-pages/CompletionStructure";
import CheckList from "./pages/project-pages/completion-structure/CheckLists";
import ImportsReports from "./pages/project-pages/completion-structure/ImportsReports";
import PunchItems from "./pages/project-pages/completion-structure/PunchItems";
import TagRegister from "./pages/project-pages/completion-structure/TagRegister";
import COMMregister from "./pages/project-pages/completion-structure/COMMregister";

// Icons
import { LogOut, LogIn, HomeIcon, User } from "lucide-react";

// Layout components that wrap their nested routes
function HomeLayout() {
  const homeConfig = {
    logo: { name: "IComS", href: "/", color: "yellow" },
    menuItems: [
      { label: "Admin Login", icon: LogIn, href: "/admin-login" },
      { label: "Project Login", icon: LogIn, href: "/project-login" },
    ],
    footerItems: [{ label: "Logout", icon: LogOut, href: "#" }],
  };
  return <Layout title="Home" config={homeConfig}><Outlet /></Layout>;
}

function LoginLayout({ title, config }) {
  return <Layout title={title} config={config}><Outlet /></Layout>;
}

function AdminLayout() {
  const adminConfig = {
    logo: { name: "IComS", href: "/", color: "yellow" },
    menuItems: [],
    footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
  };
  return <Layout title="Administrator Dashboard" config={adminConfig}><Outlet /></Layout>;
}

function ProjectLayout({ type = "dashboard" }) {
  let config;
  if (type === "login") {
    config = {
      logo: { name: "IComS", href: "/", color: "yellow" },
      menuItems: [],
      footerItems: [{ label: "Logout", icon: LogOut, href: "#" }],
    };
  } else if (type === "dashboard") {
    config = {
      logo: { name: "IComS", href: "/project-dashboard", color: "yellow" },
      menuItems: [
        { label: "Check Lists & Certificates", icon: LogIn, href: "/checklist-certificates" },
        { label: "Contractors", icon: LogIn, href: "/contractors" },
        { label: "System Structure", icon: LogIn, href: "/SystemStructure" },
        { label: "Completion Structure", icon: LogIn, href: "/completionStructure" },
      ],
      footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
    };
  } else if (type === "checklist") {
    config = {
      logo: { name: "IComS", href: "/project-dashboard", color: "yellow" },
      menuItems: [{ label: "Imports & Reports", icon: LogIn, href: "/imports-reports" }],
      footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
    };
  } else if (type === "completion") {
    config = {
      logo: { name: "IComS", href: "/project-dashboard", color: "yellow" },
      menuItems: [
        { label: "Punch Items", icon: LogIn, href: "/punchitems" },
        { label: "Check Lists", icon: LogIn, href: "/checklist" },
        { label: "Tag Register", icon: LogIn, href: "/tag-register" },
        { label: "COMM Systems", icon: LogIn, href: "/comm-register" },
        { label: "Imports & Reports", icon: LogIn, href: "/imports-reports" },
      ],
      footerItems: [{ label: "Logout", icon: LogOut, href: "/" }],
    };
  }
  return <Layout title={type.charAt(0).toUpperCase() + type.slice(1)} config={config}><Outlet /></Layout>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Home layout - fixed for home */}
        <Route path="/" element={<HomeLayout />}>
          <Route index element={<Home />} />
        </Route>

        {/* Login layouts - separate fixed layouts for each login type */}
        <Route path="/admin-login" element={<LoginLayout title="Admin Login" config={{
          logo: { name: "IComS", href: "/", color: "yellow" },
          menuItems: [],
          footerItems: [{ label: "Logout", icon: LogOut, href: "#" }],
        }} />}>
          <Route index element={<AdminLogin />} />
        </Route>

        <Route path="/project-login" element={<LoginLayout title="Project Login" config={{
          logo: { name: "IComS", href: "/", color: "yellow" },
          menuItems: [],
          footerItems: [{ label: "Logout", icon: LogOut, href: "#" }],
        }} />}>
          <Route index element={<ProjectLogin />} />
        </Route>

        {/* Admin dashboard - fixed layout for all admin pages (add more admin sub-routes here if needed) */}
        <Route path="/admin-dashboard" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
        </Route>

        {/* Project dashboard and sub-pages - fixed layout groups */}
        <Route path="/project-dashboard" element={<ProjectLayout type="dashboard" />}>
          <Route index element={<ProjectDashboard />} />
        </Route>

        <Route path="/checklist-certificates" element={<ProjectLayout type="checklist" />}>
          <Route index element={<CheckListandCertificates />} />
        </Route>

        <Route path="/contractors" element={<ProjectLayout type="checklist" />}>
          <Route index element={<Contractors />} />
        </Route>

        <Route path="/SystemStructure" element={<ProjectLayout type="checklist" />}>
          <Route index element={<SystemStructure />} />
        </Route>

        <Route path="/completionStructure" element={<ProjectLayout type="completion" />}>
          <Route index element={<CompletionStructure />} />
        </Route>

        <Route path="/checklist" element={<ProjectLayout type="completion" />}>
          <Route index element={<CheckList />} />
        </Route>

        <Route path="/imports-reports" element={<ProjectLayout type="completion" />}>
          <Route index element={<ImportsReports />} />
        </Route>

        <Route path="/punchitems" element={<ProjectLayout type="completion" />}>
          <Route index element={<PunchItems />} />
        </Route>

        <Route path="/tag-register" element={<ProjectLayout type="completion" />}>
          <Route index element={<TagRegister />} />
        </Route>

        <Route path="/comm-register" element={<ProjectLayout type="completion" />}>
          <Route index element={<COMMregister />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
} 