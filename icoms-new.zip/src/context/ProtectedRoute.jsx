// src/components/ProtectedRoute.js
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children, role }) {
  const { user } = useAuth();

  if (!user || (role && user.role !== role)) {
    return <Navigate to="/" replace />; // redirect to home if not logged in
  }

  return children;
}
